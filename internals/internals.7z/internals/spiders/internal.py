# -*- coding: utf-8 -*-
"""
Created on Fri Oct  6 14:04:34 2023

@author: msis
"""
import scrapy

from ..items import InternalsItem

class internal(scrapy.Spider):
    name='internals'
    start_urls = ['https://www.flipkart.com/laptops/pr?sid=6bo,b5g&otracker=categorytree&fm=neo%2Fmerchandising&iid=M_b12dce52-ef92-4d1d-8df1-e73cec5a368c_1_372UD5BXDFYS_MC.34WHNYFH5V2Y&otracker=hp_rich_navigation_8_1.navigationCard.RICH_NAVIGATION_Electronics~Laptop%2Band%2BDesktop_34WHNYFH5V2Y&otracker1=hp_rich_navigation_PINNED_neo%2Fmerchandising_NA_NAV_EXPANDABLE_navigationCard_cc_8_L1_view-all&cid=34WHNYFH5V2Y',]
    
    def parse(self,response):
        
        items = InternalsItem()
        
        title = response.css('div._4rR01T::text').extract()
        price = response.css('div._30jeq3 _1_WHN1::text').extract()
        deliviry_status = response.css('div._2Tpdn3::text').extract()
        processor_type = response.css('div.fMghEO::text').extract()
        
        items['title'] = title
        items['deliviry_status'] = deliviry_status
        
        yield items
                
    


